import { z } from "zod";
import type {
  ApiErrorResponse,
  CheckInResponse,
  CooldownResponse,
  DirectRequestActionResponse,
  DirectRequestResponse,
  MeResponse,
  PeopleResponse,
  SharingMode,
  SharingResponse,
  UserLookupResponse,
} from "@/lib/check-in-contract";

const userSchema = z.object({
  publicId: z.string().regex(/^[0-9A-HJKMNP-TV-Z]{4}(-[0-9A-HJKMNP-TV-Z]{4}){2}$/),
  displayName: z.string().min(1).max(50),
});

const meSchema: z.ZodType<MeResponse> = z.object({
  user: userSchema,
  lastCheckInAt: z.string().datetime().nullable(),
  serverTime: z.string().datetime(),
});

const checkInSchema: z.ZodType<CheckInResponse> = z.object({
  eventId: z.string().uuid(),
  checkedAt: z.string().datetime(),
  serverTime: z.string().datetime(),
  nextAllowedAt: z.string().datetime(),
  replayed: z.boolean(),
});

const cooldownSchema: z.ZodType<CooldownResponse> = z.object({
  code: z.literal("CHECK_IN_COOLDOWN"),
  checkedAt: z.string().datetime(),
  serverTime: z.string().datetime(),
  nextAllowedAt: z.string().datetime(),
});

const sharingModeSchema = z.enum(["OFF", "LATEST_ONLY"]);
const directRequestSchema = z.object({
  requestId: z.string().uuid(),
  direction: z.enum(["INCOMING", "OUTGOING"]),
  user: userSchema,
  createdAt: z.string().datetime(),
  expiresAt: z.string().datetime(),
});
const personSchema = z.object({
  circleId: z.string().uuid(),
  user: userSchema,
  connectedAt: z.string().datetime(),
  mySharingMode: sharingModeSchema,
  theirSharingMode: sharingModeSchema,
  lastCheckInAt: z.string().datetime().nullable(),
});
const peopleSchema: z.ZodType<PeopleResponse> = z.object({
  people: z.array(personSchema),
  incomingRequests: z.array(directRequestSchema),
  outgoingRequests: z.array(directRequestSchema),
  audienceCount: z.number().int().nonnegative(),
  serverTime: z.string().datetime(),
});
const lookupSchema: z.ZodType<UserLookupResponse> = z.object({
  user: userSchema,
  relationshipState: z.enum([
    "SELF",
    "NONE",
    "CONNECTED",
    "INCOMING_REQUEST",
    "OUTGOING_REQUEST",
  ]),
  serverTime: z.string().datetime(),
});
const directRequestResponseSchema: z.ZodType<DirectRequestResponse> = z.object({
  request: directRequestSchema,
  replayed: z.boolean(),
  serverTime: z.string().datetime(),
});
const directRequestActionSchema: z.ZodType<DirectRequestActionResponse> = z.object({
  requestId: z.string().uuid(),
  status: z.enum(["ACCEPTED", "REJECTED", "CANCELLED"]),
  person: personSchema.nullable(),
  replayed: z.boolean(),
  serverTime: z.string().datetime(),
});
const sharingResponseSchema: z.ZodType<SharingResponse> = z.object({
  circleId: z.string().uuid(),
  sharingMode: sharingModeSchema,
  serverTime: z.string().datetime(),
});

const errorSchema: z.ZodType<ApiErrorResponse> = z.object({
  code: z.string(),
  message: z.string(),
});

export class ApiError extends Error {
  constructor(
    message: string,
    readonly status: number,
    readonly body?: ApiErrorResponse | CooldownResponse,
  ) {
    super(message);
  }
}

async function request<T>(
  path: string,
  schema: z.ZodType<T>,
  init?: RequestInit,
): Promise<T> {
  const response = await fetch(path, {
    ...init,
    cache: "no-store",
    credentials: "same-origin",
    signal: init?.signal ?? AbortSignal.timeout(8_000),
    headers: {
      Accept: "application/json",
      ...(init?.body ? { "Content-Type": "application/json" } : {}),
      ...init?.headers,
    },
  });

  const contentType = response.headers.get("content-type") ?? "";
  const body = contentType.includes("application/json")
    ? await response.json().catch(() => undefined)
    : undefined;

  if (!response.ok) {
    const knownError = cooldownSchema.safeParse(body).success
      ? cooldownSchema.parse(body)
      : errorSchema.safeParse(body).success
        ? errorSchema.parse(body)
        : undefined;
    const message =
      knownError && "message" in knownError
        ? knownError.message
        : "Не удалось связаться с сервером";
    throw new ApiError(message, response.status, knownError);
  }

  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    throw new ApiError("Сервер вернул некорректный ответ", 502);
  }
  return parsed.data;
}

export async function getMe(): Promise<MeResponse | null> {
  try {
    return await request<MeResponse>("/api/v1/me", meSchema);
  } catch (error) {
    if (error instanceof ApiError && error.status === 401) return null;
    throw error;
  }
}

export function bootstrap(displayName: string, idempotencyKey: string): Promise<MeResponse> {
  return request<MeResponse>("/api/v1/bootstrap", meSchema, {
    method: "POST",
    headers: { "Idempotency-Key": idempotencyKey },
    body: JSON.stringify({ displayName }),
  });
}

export function createCheckIn(idempotencyKey: string): Promise<CheckInResponse> {
  return request<CheckInResponse>("/api/v1/check-ins", checkInSchema, {
    method: "POST",
    headers: { "Idempotency-Key": idempotencyKey },
  });
}

export function lookupUser(publicId: string): Promise<UserLookupResponse> {
  return request<UserLookupResponse>(
    `/api/v1/users/${encodeURIComponent(publicId)}`,
    lookupSchema,
  );
}

export function getPeople(signal?: AbortSignal): Promise<PeopleResponse> {
  return request<PeopleResponse>("/api/v1/people", peopleSchema, { signal });
}

export function sendDirectRequest(
  publicId: string,
  idempotencyKey: string,
): Promise<DirectRequestResponse> {
  return request<DirectRequestResponse>(
    "/api/v1/direct-requests",
    directRequestResponseSchema,
    {
      method: "POST",
      headers: { "Idempotency-Key": idempotencyKey },
      body: JSON.stringify({ publicId }),
    },
  );
}

export function actOnDirectRequest(
  requestId: string,
  action: "accept" | "reject" | "cancel",
  idempotencyKey: string,
): Promise<DirectRequestActionResponse> {
  return request<DirectRequestActionResponse>(
    `/api/v1/direct-requests/${requestId}/${action}`,
    directRequestActionSchema,
    {
      method: "POST",
      headers: { "Idempotency-Key": idempotencyKey },
    },
  );
}

export function updatePersonSharing(
  circleId: string,
  sharingMode: SharingMode,
  idempotencyKey: string,
): Promise<SharingResponse> {
  return request<SharingResponse>(
    `/api/v1/people/${circleId}/sharing`,
    sharingResponseSchema,
    {
      method: "PATCH",
      headers: { "Idempotency-Key": idempotencyKey },
      body: JSON.stringify({ sharingMode }),
    },
  );
}

export function removePerson(circleId: string, idempotencyKey: string): Promise<void> {
  return request<void>(`/api/v1/people/${circleId}`, z.void(), {
    method: "DELETE",
    headers: { "Idempotency-Key": idempotencyKey },
  });
}
